//This is my JavaScript code

//The Parallax JS code

/*Let's take a step by step look at exactly what's going on here.

1. We first find all our sections with a class of .parallax.
2. We then set our speed as a fraction between 0 and 1. In this case, I used 0.5.
3. On scroll, we loop through each of our parallax sections, finding the y offset of the window.
4. We then adjust the background-position property of our parallax section accordingly, based on our speed fraction.
5. The position of our background image is now updated each time a scroll occurs, giving the impression that it is scrolling at a slower speed than the foreground elements.*/

(function(){

  var myParallax = document.querySelectorAll(".bgImage"), speed = 0.3;

  window.onscroll = function(){
    myParallax.forEach(function(elP){

      var windowYOffset = - window.pageYOffset,
          elPBackgrounPos = "50% " + (windowYOffset * speed) + "px";

          elP.style.backgroundPosition = elPBackgrounPos;
    });

  };

})();


/*Here is the jQuery solution for the parallax*/

/*  This sample code is for jQuery solution*/

$(window).scroll(function(){
    
    var wScroll = $(this).scrollTop();
    

    if (wScroll > $(".productBox").offset().top - ($(window).height() / 1.3)) {
         
        console.log("hi");
        
        $(".productBox").each(function(i) {
            
            setTimeout(function() {
                
                $(".productBox").eq(i).addClass("isShowing");
            }, 150 * (i+1));

        });
    }
    
    if (wScroll > $(".logoC").offset().top) {
     
        $(".navC").addClass("navShowing");
        
    } else if (wScroll < $(".logoC").offset().top) {
        
        
        $(".navC").removeClass("navShowing");
    }
      
});


   
    /*  Make nav fixed at top and Highlight the current link or active link
    -----------------------------------------------*/
    
    $(function() {
        
        
        var section1C = $("#home").offset().top + 400;
        var section2C = $("#products").offset().top + 900;
        var section3C = $("#sales").offset().top + 600;
        var section4C = $("#about").offset().top + 200;
        var section5C = $("#contact").offset().top;
        
        var activeLink;
        $(document).on("scroll", function() {
        
            var scrollUp = $(document).scrollTop();
            
            if (scrollUp <= section1C) {
                
                activeLink = $(".menu-items > li:nth-child(1)");
                
            } else if (scrollUp < section2C) {
                
                activeLink = $(".menu-items > li:nth-child(2)");
            
            } else if (scrollUp < section3C) {
                
                activeLink = $(".menu-items > li:nth-child(5)");
        
            } else if (scrollUp < section4C) {
                
                activeLink = $(".menu-items > li:nth-child(3)");
        
            } else if (scrollUp < section5C) {
                
                activeLink = $(".menu-items > li:nth-child(4)");
        
            }
            
            activeLink.addClass("current");
            $(".menu-items > li").not(activeLink).removeClass("current");
        });
        
    });


/*  Smoothscroll
    -----------------------------------------------*/
   $(function() {
        $('.navC a, .scrollDownC a').bind('click', function(event) {
            var $anchor = $(this);
            $('html, body').stop().animate({
                scrollTop: $($anchor.attr('href')).offset().top - 100
            }, 1000);
            event.preventDefault();
        });
    });



/*  The Modal JavaScript
    -----------------------------------------------*/

// Get the modal
var theModal = document.getElementById('myModal');

// Get the button that opens the modal

var modalButton = document.getElementById("newCB");

modalButton.addEventListener("click", openModel, false);

function openModel() {
    
    theModal.style.display = "block";
}


// Get the <span> element that closes the modal
var span = document.getElementsByClassName("close")[0];


// When the user clicks on <span> (x), close the modal
span.onclick = function() {
    theModal.style.display = "none";
}


// When the user clicks anywhere outside of the modal, close it
window.onclick = function(event) {
    if (event.target == theModal) {
        theModal.style.display = "none";
    }
}



/*  This is the jQuery script for the mobile devices
    -----------------------------------------------*/

// Mobile Menu toggle


    $("span.navBtn").click(function() {

        $("ul.menu-items").slideToggle();
    });


    $(window).resize(function() {

        if ( $(window).width() > 480 ) {

            $("ul.menu-items").removeAttr("style");
        }
    });


    /* Hide mobile menu after clicking on a link
    -----------------------------------------------*/

    $(".menu-items li").on("click", function(){
        
        if ( $(window).width() < 800 ) {
        $("span.navBtn").click();
        }
    });




/*** DISABLE PARALLAX ON MOBILE ON SCROLL ***/


$(window).on('scroll',function(){

var windowWidth = $(window).width();

if (windowWidth <= 800) {
    
    console.log(windowWidth);
    
        $("#remParallax").removeAttr("style");

}   
    
/*** DISABLE PARALLAX ON MOBILE ON RESIZE ***/
    
$(window).on('resize', function () {
    
    var windowWidth = $(window).width();
    
    /*** DISABLE PARALLAX ON MOBILE ON LOAD ***/
    
    if (windowWidth <= 800) {
        
        console.log(windowWidth);
        
            $("#remParallax").removeAttr("style");
    } 
});
});

/*  This is the JavaScript code for the accordion
    -----------------------------------------------*/

/*This is my code for the accordion*/

var myDeliveryForm = document.getElementsByClassName("deliveryO");
var i;

for (i = 0; i < myDeliveryForm.length; i++) {
  myDeliveryForm[i].onclick = function() {
    this.classList.toggle("active");
    var myDeliveryForm = this.nextElementSibling;
    if (myDeliveryForm.style.maxHeight){
      myDeliveryForm.style.maxHeight = null;
    } else {
      myDeliveryForm.style.maxHeight = myDeliveryForm.scrollHeight + "px";
    } 
  }
}





//====================================back ground video wnen page load==================

//$(window).bind(".bgVideo", function(){
//  $(".bgVideo").load(window);
//});
//
//
//
//
//
//














/*$(window).ready(function() {
var windowWidth = $(window).width();

if(windowWidth <= 800) {
    $('.vc_parallax-content-moving').each(function () {
        $(this).removeClass('bgParallax');
    });
}   
    
** DISABLE PARALLAX ON MOBILE ON RESIZE **
$(window).on('resize', function () {
    var windowWidth = $(window).width();
    ** DISABLE PARALLAX ON MOBILE ON LOAD **
    if(windowWidth <= 800) {
        $('.vc_parallax-content-moving').each(function () {
            $(this).removeClass('bgParallax');
        });
    } else {
        $('.vc_parallax-content-moving').each(function () {
            $(this).addClass('bgParallax');
        });
    }
});
});*/



